A Pen created at CodePen.io. You can find this one at http://codepen.io/GreenSock/pen/AwCKp.

 Demonstrates runtime control of animation that's impossible with CSS-based animations.